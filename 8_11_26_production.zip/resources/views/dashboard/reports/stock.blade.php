@extends('layouts.master')

@section('content')
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h2 class="fw-bold text-dark">Stock Report</h2>
                    <p class="text-muted">Detailed inventory breakdown by SKU and Voucher Type.</p>
                </div>
                <div class="d-flex gap-2">
                    <a href="{{ route('reports.stock.export') }}" id="csv-export-link" class="btn btn-success shadow-sm">
                        <i class="fas fa-file-csv me-1"></i> Export CSV
                    </a>
                    <button class="btn btn-outline-primary shadow-sm" type="button" data-bs-toggle="offcanvas" data-bs-target="#filterOffcanvas">
                        <i class="fas fa-filter me-1"></i> Filter
                    </button>
                </div>
            </div>
        </div>
    </div>

    {{-- Offcanvas Filter --}}
    <div class="offcanvas offcanvas-end" tabindex="-1" id="filterOffcanvas" aria-labelledby="filterOffcanvasLabel">
        <div class="offcanvas-header border-bottom">
            <h5 class="offcanvas-title fw-bold" id="filterOffcanvasLabel">
                <i class="fas fa-filter me-2"></i>Filter Stock
            </h5>
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <form id="filter-form" action="{{ route('reports.stock') }}" method="GET">
                <div class="mb-4">
                    <label class="form-label fw-bold">SKU ID</label>
                    <input type="text" name="sku_id" class="form-control" placeholder="Search SKU" value="{{ request('sku_id') }}">
                </div>

                <div class="mb-4">
                    <label class="form-label fw-bold">Voucher Type</label>
                    <select name="voucher_type" class="form-select">
                        <option value="">All Types</option>
                        <option value="Online" {{ request('voucher_type') == 'Online' ? 'selected' : '' }}>Online</option>
                        <option value="Center" {{ request('voucher_type') == 'Center' ? 'selected' : '' }}>Center</option>
                    </select>
                </div>

                <div class="mb-4">
                    <label class="form-label fw-bold">Country</label>
                    <select name="country_region" class="form-select">
                        <option value="">All Countries</option>
                        @foreach($countries as $country)
                            <option value="{{ $country }}" {{ request('country_region') == $country ? 'selected' : '' }}>{{ $country }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="mb-4">
                    <label class="form-label fw-bold">City</label>
                    <select name="city" class="form-select">
                        <option value="">All Cities</option>
                        @foreach($cities ?? [] as $city)
                            <option value="{{ $city }}" {{ request('city') == $city ? 'selected' : '' }}>{{ $city }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="mb-4">
                    <label class="form-label fw-bold">Period Type</label>
                    <select name="period_type" class="form-select">
                        <option value="weekly" {{ request('period_type') == 'weekly' ? 'selected' : '' }}>Weekly</option>
                        <option value="monthly" {{ request('period_type', 'monthly') == 'monthly' ? 'selected' : '' }}>Monthly</option>
                    </select>
                </div>

                <div class="mb-4">
                    <label class="form-label fw-bold">Select Date</label>
                    <input type="date" name="filter_date" class="form-control" value="{{ request('filter_date', date('Y-m-d')) }}">
                    <small class="text-muted">Report will be generated for the month or week of this date.</small>
                </div>

                <div class="d-grid gap-2 pt-3 border-top">
                    <button type="submit" class="btn btn-primary">Apply Filters</button>
                    <a href="{{ route('reports.stock') }}" class="btn btn-light">Reset All</a>
                </div>
            </form>
        </div>
    </div>

    <div class="card shadow-sm border-0">
        <div class="card-body p-0" id="table-container">
            @include('dashboard.reports.partials.stock-table')
        </div>
    </div>
</div>

@push('scripts')
<script>
    $(document).ready(function() {
        function updateTable(url) {
            $.ajax({
                url: url,
                success: function(data) {
                    $('#table-container').html(data);
                    window.history.pushState({}, '', url);

                    let csvUrl = "{{ route('reports.stock.export') }}?" + (url.split('?')[1] || '');
                    $('#csv-export-link').attr('href', csvUrl);
                }
            });
        }

        $(document).on('click', '.ajax-pagination a', function(e) {
            e.preventDefault();
            updateTable($(this).attr('href'));
        });

        $(document).on('submit', '#filter-form', function(e) {
            e.preventDefault();
            let url = $(this).attr('action') + '?' + $(this).serialize();
            updateTable(url);

            var offcanvasElement = document.getElementById('filterOffcanvas');
            var offcanvas = bootstrap.Offcanvas.getInstance(offcanvasElement);
            if (offcanvas) offcanvas.hide();
        });
    });
</script>
@endpush
@endsection
